// ----- CONFIG -----
const API_KEY = 'YOUR_OPENWEATHERMAP_API_KEY'; // <-- replace this with your key
const BASE_URL = 'https://api.openweathermap.org/data/2.5/weather';

// ----- SELECTORS -----
const form = document.getElementById('search-form');
const cityInput = document.getElementById('city-input');
const locBtn = document.getElementById('loc-btn');
const unitBtn = document.getElementById('unit-toggle');
const statusMsg = document.getElementById('status-msg');

const card = document.getElementById('weather-card');
const placeName = document.getElementById('place-name');
const lastUpdated = document.getElementById('last-updated');
const weatherIcon = document.getElementById('weather-icon');
const tempValue = document.getElementById('temp-value');
const descEl = document.getElementById('desc');
const humidityEl = document.getElementById('humidity');
const windEl = document.getElementById('wind');
const feelsEl = document.getElementById('feels');
const pressureEl = document.getElementById('pressure');

let units = localStorage.getItem('weather_units') || 'metric'; // 'metric' or 'imperial'
unitBtn.textContent = units === 'metric' ? '°C' : '°F';

// ----- HELPERS -----
function showStatus(text) {
  statusMsg.textContent = text || '';
}

function showCard() {
  card.classList.remove('hidden');
  card.setAttribute('aria-hidden', 'false');
}
function hideCard() {
  card.classList.add('hidden');
  card.setAttribute('aria-hidden', 'true');
}

// choose background theme from main weather
function applyTheme(main) {
  document.body.className = ''; // reset
  main = (main || '').toLowerCase();
  if (main.includes('clear')) document.body.classList.add('theme-clear');
  else if (main.includes('cloud')) document.body.classList.add('theme-clouds');
  else if (main.includes('rain') || main.includes('drizzle')) document.body.classList.add('theme-rain');
  else if (main.includes('snow')) document.body.classList.add('theme-snow');
  else if (main.includes('thunder') || main.includes('storm')) document.body.classList.add('theme-thunder');
}

// format timestamp from API (seconds) to readable
function formatTime(sec) {
  const d = new Date(sec * 1000);
  return d.toLocaleString();
}

// convert wind speed (m/s -> km/h) if metric; if imperial, API returns miles/h already
function formatWind(speed, units) {
  if (units === 'metric') {
    // OpenWeather returns m/s for metric: convert to km/h
    return `${Math.round(speed * 3.6)} km/h`;
  } else {
    // imperial: mph
    return `${Math.round(speed)} mph`;
  }
}

// ----- FETCHING -----
async function fetchWeatherByCity(city) {
  try {
    showStatus('Loading weather...');
    hideCard();

    const url = `${BASE_URL}?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=${units}`;
    const res = await fetch(url);
    if (!res.ok) {
      if (res.status === 404) throw new Error('City not found. Try another name.');
      throw new Error('Weather fetch failed. HTTP ' + res.status);
    }
    const data = await res.json();
    renderWeather(data);
    showStatus('');
    // remember last city
    localStorage.setItem('last_city', city);
  } catch (err) {
    showStatus(err.message);
    console.error(err);
  }
}

async function fetchWeatherByCoords(lat, lon) {
  try {
    showStatus('Loading weather for your location...');
    hideCard();

    const url = `${BASE_URL}?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=${units}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Weather fetch failed. HTTP ' + res.status);
    const data = await res.json();
    renderWeather(data);
    showStatus('');
  } catch (err) {
    showStatus(err.message);
    console.error(err);
  }
}

// ----- RENDER -----
function renderWeather(data) {
  // data structure: see OpenWeatherMap docs
  const name = data.name;
  const country = data.sys && data.sys.country ? data.sys.country : '';
  const main = data.weather && data.weather[0] ? data.weather[0].main : '';
  const description = data.weather && data.weather[0] ? data.weather[0].description : '';
  const icon = data.weather && data.weather[0] ? data.weather[0].icon : '';
  const temp = data.main && data.main.temp != null ? data.main.temp : '--';
  const feels = data.main && data.main.feels_like != null ? data.main.feels_like : '--';
  const humidity = data.main && data.main.humidity != null ? data.main.humidity : '--';
  const pressure = data.main && data.main.pressure != null ? data.main.pressure : '--';
  const windSpeed = data.wind && data.wind.speed != null ? data.wind.speed : '--';
  const dt = data.dt || Math.floor(Date.now() / 1000);

  placeName.textContent = `${name}${country ? ', ' + country : ''}`;
  lastUpdated.textContent = `Updated: ${formatTime(dt)}`;
  weatherIcon.src = icon ? `https://openweathermap.org/img/wn/${icon}@2x.png` : '';
  weatherIcon.alt = description || main || 'weather icon';
  tempValue.textContent = `${Math.round(temp)}°`;
  descEl.textContent = description || main;
  humidityEl.textContent = `${humidity} %`;
  windEl.textContent = formatWind(windSpeed, units);
  feelsEl.textContent = `${Math.round(feels)}°`;
  pressureEl.textContent = `${pressure} hPa`;

  applyTheme(main);
  showCard();
}

// ----- EVENTS -----
form.addEventListener('submit', (e) => {
  e.preventDefault();
  const city = cityInput.value.trim();
  if (!city) {
    showStatus('Please enter a city name.');
    return;
  }
  fetchWeatherByCity(city);
});

locBtn.addEventListener('click', () => {
  if (!navigator.geolocation) {
    showStatus('Geolocation not supported in your browser.');
    return;
  }
  showStatus('Requesting location...');
  navigator.geolocation.getCurrentPosition((pos) => {
    const lat = pos.coords.latitude;
    const lon = pos.coords.longitude;
    fetchWeatherByCoords(lat, lon);
  }, (err) => {
    showStatus('Location permission denied or unavailable.');
    console.warn(err);
  }, { timeout: 10000 });
});

unitBtn.addEventListener('click', () => {
  units = units === 'metric' ? 'imperial' : 'metric';
  unitBtn.textContent = units === 'metric' ? '°C' : '°F';
  localStorage.setItem('weather_units', units);
  // re-fetch last shown city (if any) to update units
  const last = localStorage.getItem('last_city');
  if (last) fetchWeatherByCity(last);
});

// Auto-load last searched city on start if available
window.addEventListener('load', () => {
  const last = localStorage.getItem('last_city');
  if (last) {
    cityInput.value = last;
    fetchWeatherByCity(last);
  } else {
    showStatus('Type a city or press "Use my location".');
  }
});
